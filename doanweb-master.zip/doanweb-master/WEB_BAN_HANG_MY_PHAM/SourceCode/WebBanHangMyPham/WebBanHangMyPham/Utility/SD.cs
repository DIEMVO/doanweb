﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebBanHangMyPham.Utility
{
    public static class SD
    {
        public const string DefaultSkincareImage = "default_skincare.png";
    }
}
